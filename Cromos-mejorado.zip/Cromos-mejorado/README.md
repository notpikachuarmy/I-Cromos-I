# Tototo Clicker 2.1

Juego clicker de colección de cromos preparado para publicarse directamente en GitHub Pages, sin proceso de compilación.

## Mejoras incluidas

- Carga de datos más resistente: usa caché local y admite CSV locales como respaldo.
- Pantalla de carga y mensajes de error útiles, en lugar de dejar la interfaz bloqueada.
- Aplicación instalable (PWA) y caché progresiva para jugar tras una primera visita con conexión.
- Recompensa de producción pasiva al volver, limitada a 8 horas.
- Tema claro/oscuro y control de sonido persistentes.
- Navegación por teclado, foco visible y modales con mejor gestión del foco.
- Buscador y filtros por rareza/estado dentro de cada álbum.
- Apertura múltiple optimizada: 100 sobres se procesan en una sola transacción y con un único refresco final.
- Imágenes convertidas de PNG a WebP: el peso de los recursos gráficos baja aproximadamente de 54,4 MB a 10,6 MB.
- Última pestaña visitada recordada entre sesiones.

## Publicar en GitHub Pages

1. Sube el contenido de esta carpeta a la rama principal del repositorio.
2. En GitHub, abre **Settings → Pages**.
3. En **Build and deployment**, elige **Deploy from a branch**.
4. Selecciona la rama principal y la carpeta raíz `/`.
5. Guarda los cambios.

No necesita Node, npm, Vite ni ningún generador estático.

## Datos de cromos y álbumes

Las URLs de los Google Sheets están en la parte superior de `game.js`.

El flujo de carga es:

1. Si ya existe una copia válida en el navegador, el juego arranca inmediatamente con ella.
2. En segundo plano intenta actualizarla desde Google Sheets.
3. En una primera visita intenta Google Sheets y, si falla, busca `data/cromos.csv` y `data/albumes.csv`.
4. Si no hay ninguna fuente disponible, muestra un error con botón para reintentar.

Consulta `data/README.md` para crear los respaldos locales.

## Estructura

- `index.html`: interfaz y modales.
- `style.css`: diseño responsive, temas y accesibilidad.
- `game.js`: estado, carga de datos, navegación, guardado y bucles del juego.
- `shop.js`: sobres, probabilidades, duplicados y fragmentos.
- `albums.js`: álbumes, filtros, progreso y cromos.
- `sw.js` y `manifest.webmanifest`: instalación y funcionamiento offline progresivo.
- `Cromos/` y `Portadas/`: imágenes WebP optimizadas.

## Ideas para una siguiente versión

- Sistema de códigos semanales o eventos temporales.
- Sobres con animación de apertura y opción de “saltar animación”.
- Protección contra mala suerte: garantizar una rareza alta después de cierto número de sobres.
- Mercado/intercambio mediante códigos exportables, sin servidor.
- Retos diarios con rachas y recompensas cosméticas.
- Estadísticas visuales de probabilidades, progreso por álbum y tiempo estimado de finalización.
- Sincronización opcional en la nube mediante un backend independiente.

## Comprobaciones recomendadas antes de publicar

- Verifica que ambos Google Sheets continúen publicados como CSV.
- Prueba exportar e importar una partida antigua.
- Abre al menos un sobre de cada álbum para comprobar sus tags.
- Revisa la instalación desde un navegador compatible después de publicar con HTTPS.
